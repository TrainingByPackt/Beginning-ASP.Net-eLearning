﻿using System;
using System.Collections.Generic;
using System.Text;

namespace RestBuy.Entities
{
    public class Supplier : BaseEntity
    {
        public string Name { get; set; }
    }

}
